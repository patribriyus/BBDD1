
/* Creacion de las tablas */
DROP TABLE Matriculas;

DROP TABLE Asignaturas;

DROP TABLE Alumnos;

